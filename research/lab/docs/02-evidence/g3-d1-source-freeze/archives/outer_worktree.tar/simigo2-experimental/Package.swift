// swift-tools-version:5.9

import PackageDescription

let package = Package(
    name: "SimiGo2Experimental",
    platforms: [
        .macOS(.v14)
    ],
    products: [
        .library(name: "SimiGo2Experimental", targets: ["SimiGo2Experimental"]),
        .library(name: "SimiGoRuntimeContract", targets: ["SimiGoRuntimeContract"]),
        .executable(name: "simigo2ctl", targets: ["simigo2ctl"]),
        .executable(name: "ActualMLXSmokeChild", targets: ["ActualMLXSmokeChild"]),
        .executable(name: "EngineBaselineCrashChild", targets: ["EngineBaselineCrashChild"]),
        .executable(name: "MaterializationQuarantineCrashChild", targets: ["MaterializationQuarantineCrashChild"]),
        .executable(name: "ExecutionStateChaosChild", targets: ["ExecutionStateChaosChild"]),
        .executable(name: "g3-swift-isolation-entry", targets: ["G3SwiftIsolationEntry"]),
        // G6/G7b: the real D1 worker and supervisor. Both are contract-only
        // (SimiGoRuntimeContract), so they cannot reach the ungated executor
        // surface (SimiGo2Experimental) and are model-free: the isolation gate
        // refuses under the empty trust registry before any model call or
        // binding consumption (G8a). Their identity is bound by G3_EXPECT_EXEC_SHA256.
        .executable(name: "G3D1Worker", targets: ["G3D1Worker"]),
        .executable(name: "G3D1Supervisor", targets: ["G3D1Supervisor"]),
        .executable(name: "SimiGo2App", targets: ["SimiGo2App"])
    ],
    dependencies: [
        // G3 native storage-identity accessor lives in the Cmlx C++ interop
        // boundary, so the fork is consumed as a LOCAL PATH dependency while the
        // accessor is authored and tested. Path identity "mlx-swift" overrides the
        // transitive remote inside mlx-swift-lm. To revert to the pinned remote:
        //   .package(url: "https://github.com/slamfinger/mlx-swift", revision: "ef5f1b6bb24e27922189316362f3057c64261704"),
        // The editable clone is a working copy of ef5f1b6 at ../vendor/mlx-swift
        // (gitignored under the lab repo; push its branch to the fork to upstream).
        .package(path: "../vendor/mlx-swift"),
        // The native KV-cache write-boundary observer (KVCacheWriteObserver) lives
        // inside MLXLMCommon.KVCacheSimple.update, so mlx-swift-lm is consumed as a
        // LOCAL PATH dependency while that seam is authored and tested — exactly as
        // the storage-identity accessor drove the mlx-swift path dep. The editable
        // clone is a working copy of the pinned revision eab6895 on branch
        // feature/g3-kv-write-observer at ../vendor/mlx-swift-lm (gitignored under
        // the lab repo; push the branch to slamfinger/mlx-swift-lm to upstream).
        // To revert to the pinned remote:
        //   .package(url: "https://github.com/slamfinger/mlx-swift-lm.git",
        //            branch: "release/v2.0-beta-ml"),
        .package(path: "../vendor/mlx-swift-lm"),
        .package(url: "https://github.com/huggingface/swift-transformers.git", from: "1.3.3"),
    ],
    targets: [
        .target(
            name: "SimiGoRuntimeContract"
        ),
        .target(
            name: "SimiGo2Experimental",
            dependencies: [
                "SimiGoRuntimeContract",
                .product(name: "MLX", package: "mlx-swift"),
                .product(name: "MLXLMCommon", package: "mlx-swift-lm"),
                .product(name: "MLXLLM", package: "mlx-swift-lm"),
                .product(name: "MLXHuggingFace", package: "mlx-swift-lm"),
                .product(name: "Tokenizers", package: "swift-transformers"),
                .product(name: "MLXNN", package: "mlx-swift")
            ]
        ),
    .executableTarget(
            name: "simigo2ctl",
            dependencies: [
                "SimiGo2Experimental",
                .product(name: "MLX", package: "mlx-swift"),
                .product(name: "MLXLMCommon", package: "mlx-swift-lm"),
                .product(name: "MLXLLM", package: "mlx-swift-lm"),
                .product(name: "MLXHuggingFace", package: "mlx-swift-lm"),
                .product(name: "Tokenizers", package: "swift-transformers"),
                .product(name: "MLXNN", package: "mlx-swift")
            ]
        ),
        .executableTarget(
            name: "ActualMLXSmokeChild",
            dependencies: [
                "SimiGo2Experimental",
                "SimiGoRuntimeContract",
                .product(name: "MLX", package: "mlx-swift"),
                .product(name: "MLXLMCommon", package: "mlx-swift-lm"),
                .product(name: "MLXLLM", package: "mlx-swift-lm"),
                .product(name: "MLXHuggingFace", package: "mlx-swift-lm"),
                .product(name: "Tokenizers", package: "swift-transformers")
            ]
        ),
        .executableTarget(
            name: "SimiGo2App",
            dependencies: ["SimiGo2Experimental"]
        ),
        .executableTarget(
            name: "EngineBaselineCrashChild",
            dependencies: ["SimiGo2Experimental"]
        ),
        .executableTarget(
            name: "MaterializationQuarantineCrashChild",
            dependencies: ["SimiGo2Experimental"]
        ),
        .executableTarget(
            name: "ExecutionStateChaosChild",
            dependencies: ["SimiGo2Experimental"]
        ),
        // Native G3 isolation-gate control point, invoked by the Python research
        // harness. MLX-free and model-free: it only exercises the gate's control
        // flow (attestation -> requireIsolation -> generation), so the boundary
        // is callable and testable without loading a model or the MLX runtime.
        .executableTarget(
            name: "G3SwiftIsolationEntry",
            dependencies: ["SimiGoRuntimeContract"]
        ),
        // G3D1WorkerCore: the shared, contract-only logic for the D1 worker and
        // supervisor (identity self-check, one-shot authorization, model-free
        // gated dual-arm control flow, auditable records). It MUST NOT depend on
        // SimiGo2Experimental — that is the G8b-A boundary the manifest checks.
        .target(
            name: "G3D1WorkerCore",
            dependencies: ["SimiGoRuntimeContract"]
        ),
        .executableTarget(
            name: "G3D1Worker",
            dependencies: ["G3D1WorkerCore", "SimiGoRuntimeContract"]
        ),
        .executableTarget(
            name: "G3D1Supervisor",
            dependencies: ["G3D1WorkerCore", "SimiGoRuntimeContract"]
        ),
        .testTarget(
            name: "G3D1SupervisorTests",
            dependencies: ["G3D1WorkerCore", "SimiGoRuntimeContract"]
        ),
        .testTarget(
            name: "SimiGoRuntimeContractTests",
            dependencies: ["SimiGoRuntimeContract"]
        ),
        .testTarget(
            name: "SimiGo2ExperimentalTests",
            dependencies: [
                "SimiGo2Experimental", "SimiGoRuntimeContract",
                .product(name: "MLX", package: "mlx-swift"),
                // The real KV cache under test (KVCacheSimple.update) lives in
                // MLXLMCommon; linking it lets the during-generation allocation
                // gateway be exercised against the genuine cache lifecycle without
                // loading a model.
                .product(name: "MLXLMCommon", package: "mlx-swift-lm")
            ]
        )
    ]
)
